const Room = require("../models/Room");
const express = require("express");
const router = express.Router();

router.post("/save", async (req, res) => {
  const { roomId, code } = req.body;
  try {
    const room = await Room.findOneAndUpdate(
      { roomId },
      { code },
      { upsert: true, new: true }
    );
    res.status(200).json(room);
  } catch (err) {
    res.status(500).json({ error: "Failed to save" });
  }
});

router.get("/", async (req, res) => {
  try {
    const rooms = await Room.find({}, "roomId");
    res.status(200).json(rooms);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch rooms" });
  }
});

router.get("/:roomId", async (req, res) => {
  try {
    const room = await Room.findOne({ roomId: req.params.roomId });
    if (room) res.status(200).json(room);
    else res.status(404).json({ error: "Not found" });
  } catch (err) {
    res.status(500).json({ error: "Error fetching room" });
  }
});

module.exports = router;
