const mongoose = require("mongoose");

const codeSnapshotSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    roomId: { type: String },
    language: { type: String },
    code: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("CodeSnapshot", codeSnapshotSchema);
