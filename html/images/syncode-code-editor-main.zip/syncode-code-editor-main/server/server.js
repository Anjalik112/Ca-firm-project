// server.js
const express = require("express");
const app = express();
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");
const ACTIONS = require("./Actions");
const axios = require("axios");
const connectDB = require("./config/db");
const cors = require("cors");
const Room = require("./models/Room");
const roomRoutes = require("./routes/roomRoutes");

connectDB();
app.use(
  cors({
    origin: "https://syncode-code-editor.vercel.app",
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  })
);

app.use(express.json());
app.use("/api/rooms", roomRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "https://syncode-code-editor.vercel.app",
    methods: ["GET", "POST"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  },
});
const userSocketMap = {};

function getAllConnectedMembers(roomId) {
  const socketIds = Array.from(io.sockets.adapter.rooms.get(roomId) || []);
  const seenUsernames = new Set();
  const uniqueMembers = [];
  socketIds.forEach((socketId) => {
    const username = userSocketMap[socketId];
    if (!seenUsernames.has(username)) {
      seenUsernames.add(username);
      uniqueMembers.push({
        socketId,
        username,
      });
    }
  });
  return uniqueMembers;
}

io.on("connection", (socket) => {
  console.log("Socket connected:", socket.id);

  socket.on(ACTIONS.JOIN, async ({ roomId, username }) => {
    const existing = getAllConnectedMembers(roomId).find(
      (member) => member.username === username
    );

    if (existing) {
      socket.emit("username-taken", {
        message: "Username already taken in this room.",
      });
      return;
    }

    userSocketMap[socket.id] = username;
    socket.join(roomId);

    await Room.findOneAndUpdate(
      { roomId },
      {
        $addToSet: { users: username },
        $setOnInsert: { createdAt: new Date() },
      },
      { upsert: true }
    );

    const members = getAllConnectedMembers(roomId);

    members.forEach(({ socketId }) => {
      io.to(socketId).emit(ACTIONS.JOINED, {
        members,
        username,
        socketId: socket.id,
      });
    });
  });

  socket.on(ACTIONS.CODE_CHANGE, ({ roomId, code }) => {
    socket.in(roomId).emit(ACTIONS.CODE_CHANGE, { code });
  });

  socket.on(ACTIONS.SYNC_CODE, ({ socketId, code }) => {
    io.to(socketId).emit(ACTIONS.CODE_CHANGE, { code });
  });

  socket.on(ACTIONS.TYPING, ({ roomId, username }) => {
    socket.in(roomId).emit(ACTIONS.TYPING, { username });
  });

  socket.on("compileCode", async ({ code, roomId, language }) => {
    try {
      const languageMap = {
        javascript: {
          language: "javascript",
          version: "18.15.0",
          runtime: "node",
        },
        python: { language: "python", version: "3.10.0" },
        java: { language: "java", version: "15.0.2" },
        cpp: { language: "c++", version: "10.2.0", runtime: "gcc" },
      };
      const langConfig = languageMap[language] || languageMap.javascript;

      const response = await axios.post(
        "https://emkc.org/api/v2/piston/execute",
        {
          language: langConfig.language,
          version: langConfig.version,
          files: [{ content: code }],
          runtime: langConfig.runtime,
        }
      );

      await Room.findOneAndUpdate({ roomId }, { lastCode: code, language });

      io.to(roomId).emit("codeResponse", response.data);
    } catch (err) {
      console.error("Compilation error:", err);
      io.to(roomId).emit("codeResponse", {
        run: {
          output: err.response?.data?.message || "Compilation failed",
          stderr: err.response?.data?.stderr || err.message,
        },
      });
    }
  });

  socket.on("disconnecting", () => {
    const rooms = [...socket.rooms];
    rooms.forEach((roomId) => {
      socket.in(roomId).emit(ACTIONS.DISCONNECTED, {
        socketId: socket.id,
        username: userSocketMap[socket.id],
      });
    });
    delete userSocketMap[socket.id];
    socket.leave();
  });
});
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Listening on port ${PORT}`));
