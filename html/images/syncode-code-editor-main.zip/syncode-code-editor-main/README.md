# SYNCODE — Real-time Collaborative Code Editor

SYNCODE is a real-time collaborative code editor that allows multiple users to join a room, edit code together and compile code in multiple languages (JavaScript, Python, C++, Java) using [Piston API](https://github.com/engineer-man/piston).
Also saves and return to your coding sessions.

---

## Features

- Real-time collaboration with Socket.IO
- Code editor using CodeMirror Editor
- Multiple language support (JS, Python, C++, Java)
- Live code compilation with output
- Custom room-based sessions
- Saved Rooms.

---

## Tech Stack

| Tech              | Role                    |
| ----------------- | ----------------------- |
| React + Vite      | Frontend                |
| Node.js + Express | Backend + API routing   |
| MongoDB           | Storing Data            |
| Socket.IO         | Real-time communication |
| Piston API        | Code compilation        |

---

## 🛠️ Setup Instructions

### 1. Clone the Repo

```bash
git clone https://github.com/Tanmayie03/syncode.git
cd syncode
```

### 2. Backend Setup

```bash
cd server
npm install
```

### 3. .env Setup

```bash
MONGO_URI=your_mongodb_connection_string
PORT=5000
```

### 3. Frontend Setup

```bash
cd ../client
npm install
npm run dev
```

---

#### Frontend runs on: http://localhost:5173

#### Backend runs on: http://localhost:5000

---
