export const saveRoom = async (roomId, code) => {
  const res = await fetch(
    "https://syncode-code-editor.onrender.com/api/rooms/save",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roomId, code }),
    }
  );
  return res.json();
};

export const getSavedRooms = async () => {
  const res = await fetch("https://syncode-code-editor.onrender.com/api/rooms");
  return res.json();
};

export const getRoomCode = async (roomId) => {
  const res = await fetch(
    `https://syncode-code-editor.onrender.com/api/rooms/${roomId}`
  );
  return res.json();
};
