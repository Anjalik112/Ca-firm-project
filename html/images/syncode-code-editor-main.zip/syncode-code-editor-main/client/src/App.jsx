import { EditorPage } from "./pages/EditorPage";
import { Home } from "./pages/Home";
import "./index.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
function App() {
  return (
    <>
      <div className="">
        <Toaster
          position="top-center"
          toastOptions={{
            className: "",
            style: {
              border: "1px solid #0f172b",
              padding: "8px 16px",
              color: "#ffffff",
              background: "#272727",
            },
          }}></Toaster>
      </div>
      <BrowserRouter>
        <div className=" ">
          <Routes>
            <Route path="/" element={<Home />}></Route>
            <Route path="/editor/:roomId" element={<EditorPage />}></Route>
          </Routes>
        </div>
      </BrowserRouter>
    </>
  );
}

export default App;
