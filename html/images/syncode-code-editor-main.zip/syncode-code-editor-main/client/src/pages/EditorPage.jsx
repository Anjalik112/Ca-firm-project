import { useEffect, useRef, useState } from "react";
import { Members } from "../components/Members";
import { Editor } from "../components/Editor";
import { initSocket } from "../../socket";
import {
  useLocation,
  useNavigate,
  Navigate,
  useParams,
} from "react-router-dom";
import toast from "react-hot-toast";
import ACTIONS from "../Actions";
import { saveRoom, getSavedRooms, getRoomCode } from "../utils/api";

export const EditorPage = () => {
  const socketRef = useRef(null);
  const codeRef = useRef(null);
  const editorRef = useRef(null);

  const [typing, setTyping] = useState("");

  const location = useLocation();
  const reactNavigator = useNavigate();
  const { roomId } = useParams();
  const [savedRooms, setSavedRooms] = useState([]);
  const [members, setMembers] = useState([]);
  const [language, setLanguage] = useState("javascript");
  const [typingUser, setTypingUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSave = async () => {
    const code = editorRef.current?.getValue() || "";
    await saveRoom(roomId, code);
    toast.success("Room saved!");
    loadSavedRooms();
  };

  const loadSavedRooms = async () => {
    const rooms = await getSavedRooms();
    setSavedRooms(rooms);
  };

  const loadRoom = async (roomId) => {
    const data = await getRoomCode(roomId);
    editorRef.current?.setValue(data.code);
  };

  useEffect(() => {
    loadSavedRooms();
  }, []);

  const [code, setCode] = useState(() => {
    switch (language) {
      case "python":
        return "# Write your Python code here";
      case "java":
        return "// Write your Java code here";
      case "cpp":
        return "// Write your C++ code here";
      default:
        return "// Write your JavaScript code here";
    }
  });
  const [outPut, setOutPut] = useState({
    output: "",
    error: "",
    message: "",
  });
  const [version, setVersion] = useState("*");

  useEffect(() => {
    const init = async () => {
      socketRef.current = await initSocket();

      socketRef.current.on("connect_error", handleErrors);
      socketRef.current.on("connect_failed", handleErrors);

      function handleErrors(e) {
        console.log("socket error", e);
        toast.error("Socket connection failed");
        reactNavigator("/");
      }

      socketRef.current.emit(ACTIONS.JOIN, {
        roomId,
        username: location.state?.username,
      });

      socketRef.current.on(
        ACTIONS.JOINED,
        ({ members, username, socketId }) => {
          if (username !== location.state?.username) {
            toast.success(`${username} joined the room`);
          }
          setMembers(members);

          const code = editorRef.current?.getValue();
          if (code) {
            socketRef.current.emit(ACTIONS.SYNC_CODE, { socketId, code });
          }

          socketRef.current.emit(ACTIONS.LANGUAGE_CHANGE, {
            roomId,
            language,
          });
        }
      );

      socketRef.current.on(ACTIONS.TYPING, (user) => {
        setTyping(`${user.slice(0, 8)}... is Typing`);
        setTimeout(() => setTyping(""), 2000);
      });

      socketRef.current.on(ACTIONS.DISCONNECTED, ({ username, socketId }) => {
        toast.success(`${username} left the room`);
        setMembers((prev) =>
          prev.filter((member) => member.socketId !== socketId)
        );
      });

      socketRef.current.on(ACTIONS.CODE_CHANGE, ({ code }) => {
        if (editorRef.current) {
          const currentCode = editorRef.current.getValue();
          if (code !== currentCode) {
            const cursor = editorRef.current.getCursor();
            editorRef.current.setValue(code);
            editorRef.current.setCursor(cursor);
          }
        }
      });

      socketRef.current.on(ACTIONS.LANGUAGE_CHANGE, ({ language }) => {
        setLanguage(language);
      });

      socketRef.current.on(ACTIONS.TYPING, ({ username }) => {
        setTypingUser(username);
        setTimeout(() => setTypingUser(null), 1000);
      });

      socketRef.current.on("codeResponse", (response) => {
        setIsLoading(false);
        if (response.run) {
          setOutPut({
            output: response.run.output || "",
            error: response.run.stderr || "",
            message: response.run.output ? "" : response.message || "No output",
          });
        } else {
          setOutPut({
            output: "",
            error: response.message || "Execution failed",
            message: "",
          });
        }
      });
    };
    init();

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current.off(ACTIONS.JOINED);
        socketRef.current.off(ACTIONS.DISCONNECTED);
        socketRef.current.off(ACTIONS.CODE_CHANGE);
        socketRef.current.off(ACTIONS.LANGUAGE_CHANGE);
        socketRef.current.off("codeResponse");
      }
    };
  }, []);

  if (!location.state) {
    return <Navigate to="/" />;
  }

  const handleLanguageChange = (e) => {
    const lang = e.target.value;
    setLanguage(lang);

    switch (lang) {
      case "python":
        setCode("# Write your Python code here");
        break;
      case "java":
        setCode("// Write your Java code here");
        break;
      case "cpp":
        setCode("// Write your C++ code here");
        break;
      default:
        setCode("// Write your JavaScript code here");
    }

    socketRef.current.emit(ACTIONS.LANGUAGE_CHANGE, {
      roomId,
      language: lang,
    });
  };

  const handleRunCode = () => {
    setIsLoading(true);
    const codeToRun = codeRef.current;
    socketRef.current.emit(
      "compileCode",
      {
        code: codeToRun,
        roomId,
        language,
      },
      () => {
        setIsLoading(false);
      }
    );
  };
  return (
    <div className="flex h-screen overflow-hidden text-white bg-slate-950 w-full">
      <div className="bg-slate-900 border-r border-slate-600 min-w-64 p-4 flex flex-col justify-between">
        <div>
          <div className="w-28">
            <img src="/logo.png" className="w-full" />
          </div>

          <div className="border-t border-slate-700 pt-4">
            <p className="text-sm text-blue-500">Select the language</p>
            <div className="py-2">
              <select
                className="language-selector text-sm outline-none w-full p-2 bg-slate-800 text-white border border-slate-600 rounded "
                value={language}
                onChange={handleLanguageChange}>
                <option value="javascript">JavaScript</option>
                <option value="python">Python</option>
                <option value="java">Java</option>
                <option value="cpp">C++</option>
              </select>
            </div>
            <div className="border-t border-slate-700 py-2 my-3">
              <p className="text-sm text-gray-400 mb-2">
                Connected ({members.length}) coders
              </p>
              <div className="grid grid-cols-2 overflow-y-scroll justify-center items-start my-4 gap-2 max-h-60">
                {members.map((member) => (
                  <Members
                    key={member.socketId}
                    username={member.username}
                    isCurrentUser={member.username === location.state?.username}
                  />
                ))}
              </div>
              <p className="typing-indicator">{typing}</p>
              {typingUser && (
                <p className="typing-indicator">{typingUser} is typing...</p>
              )}
            </div>
          </div>
        </div>
        <div className="">
          <div className="flex-1 ">
            <div className="flex gap-2 text-sm ">
              <button
                className="px-2 py-2 flex  items-center gap-1 cursor-pointer bg-white text-slate-900 font-semibold hover:bg-slate-50 rounded"
                onClick={() => {
                  navigator.clipboard.writeText(roomId);
                  toast.success("Room ID copied!");
                }}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 20 24"
                  strokeWidth="1.5"
                  stroke="currentColor"
                  className="size-6">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 0 0-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 0 1-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H9.75"
                  />
                </svg>
                Room ID
              </button>

              <button
                className="p-2 flex cursor-pointer items-center gap-1 font-semibold bg-red-500 hover:bg-red-600 rounded"
                onClick={() => {
                  reactNavigator("/");
                }}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="1.5"
                  stroke="currentColor"
                  className="size-6">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9"
                  />
                </svg>
                Leave
              </button>
            </div>
          </div>
          <div className=" bg-gray-800 text-white mt-2 p-2">
            <h2 className="text-blue-500 font-bold mb-2">Saved Rooms</h2>
            <ul className="overflow-y-scroll h-20">
              {savedRooms.map((room) => (
                <li
                  key={room.roomId}
                  className="cursor-pointer text-[10px] border-b border-slate-500 pb-1 list-disc hover:text-slate-300"
                  onClick={() => loadRoom(room.roomId)}>
                  {room.roomId}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <div className="w-full flex flex-col justify-between">
        <Editor
          socketRef={socketRef}
          roomId={roomId}
          onCodeChange={(code) => {
            codeRef.current = code;
            setCode(code);
          }}
          editorRef={editorRef}
          initialLanguage={language}
          onTyping={() => {
            socketRef.current.emit(ACTIONS.TYPING, {
              roomId,
              username: location.state.username,
            });
          }}
        />
        <button
          onClick={handleSave}
          className="bg-blue-500 absolute right-2 text-sm top-4 text-white px-4 py-1 rounded mb-4">
          Save
        </button>
        <div className=" relative">
          <div className="flex p-2 border-t border-slate-600 justify-between">
            <span className=""> Output</span>

            <button
              className={`px-3 py-1 text-sm flex items-center gap-1 ${
                isLoading ? "bg-gray-500" : "bg-green-500 hover:bg-green-600"
              } rounded-md transition-colors`}
              onClick={handleRunCode}
              disabled={isLoading}>
              {isLoading ? (
                <>
                  <span className="inline-block text-sm px-2 py-1 border-2 border-white border-tx-transparent animate-spin"></span>
                  Running...
                </>
              ) : (
                <>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 22 22"
                    strokeWidth="1.5"
                    stroke="currentColor"
                    className="size-5">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z"
                    />
                  </svg>
                  Run
                </>
              )}
            </button>
          </div>

          <textarea
            className={`output-console w-full p-3 min-h-48 max-h-48 font-mono text-sm ${
              outPut.error
                ? "bg-red-900/50 text-red-200"
                : "bg-slate-900 text-white"
            }`}
            readOnly
            rows={8}
            value={
              outPut.error
                ? `Error: ${outPut.error}`
                : outPut.output || outPut.message
            }
          />
        </div>
      </div>
    </div>
  );
};
