import { useState } from "react";
import { v4 as uuidV4 } from "uuid";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
export const Home = () => {
  const navigate = useNavigate();
  const [roomId, setRoomId] = useState("");
  const [username, setUsername] = useState("");
  const joinRoom = () => {
    if (!roomId || !username) {
      toast.error("Room ID & username is required");
      return;
    }
    navigate(`/editor/${roomId}`, {
      state: {
        username,
      },
    });
  };

  const createNewRoom = (e) => {
    e.preventDefault();
    const id = uuidV4();
    setRoomId(id);
    toast.success("Created a new room");
  };
  return (
    <div className="flex w-full bg-slate-950 text-white h-screen  items-center justify-between">
      <div className="relative w-1/2 h-screen flex justify-center items-center bg-slate-900">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "url('https://img.freepik.com/free-vector/gradient-black-background-with-wavy-lines_23-2149158441.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "opacity(0.3)",
            zIndex: 0,
          }}></div>

        <img
          src="./heroImage.png"
          className="relative z-10 brightness-90 w-3/5 h-fit"
        />
      </div>

      <div className="bg-slate-900 flex-1 mx-28 p-8 max-w-6xl min-w-md">
        <img src="./logo2.png" className="w-1/3 mx-auto mb-6" />

        <p className="text-sm ">Paste your invitation ROOM ID-</p>
        <div className="flex flex-col py-2 gap-y-4">
          <input
            type="text"
            className="outline-none px-4 py-2 text-white bg-slate-800"
            placeholder="Room ID"
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
          />
          <input
            type="text"
            className="outline-none px-4 py-2 text-white bg-slate-800"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button
            onClick={joinRoom}
            className="px-4 w-full my-2 cursor-pointer mx-auto rounded font-bold bg-green-600 hover:bg-green-700 py-2">
            Join room
          </button>
        </div>
        <p className="text-sm pt-4  text-center">
          Create a Room ID and invite other coders:
          <span className="">
            <button
              onClick={createNewRoom}
              className="text-green-500 cursor-pointer font-semibold underline underline-offset-4 pl-1">
              {" "}
              New Room
            </button>
          </span>{" "}
        </p>
      </div>
    </div>
  );
};
