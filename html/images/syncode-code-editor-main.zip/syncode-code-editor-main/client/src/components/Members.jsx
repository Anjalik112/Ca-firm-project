import Avatar from "react-avatar";

export const Members = ({ username, isCurrentUser }) => {
  return (
    <div className="flex relative   h-full p-2 flex-col items-center  text-sm">
      <Avatar name={username} size="50" round="8px" />
      <span className="mt-1 text-center">
        {username}
        <br />
        {isCurrentUser && <span className="text-gray-400"> (You)</span>}
      </span>
    </div>
  );
};
