import { useEffect } from "react";
import "codemirror/lib/codemirror.css";
import "codemirror/theme/material-ocean.css";
import "codemirror/mode/javascript/javascript";
import "codemirror/addon/edit/closetag";
import "codemirror/addon/edit/closebrackets";
import CodeMirror from "codemirror";
import ACTIONS from "../Actions";

export const Editor = ({ socketRef, roomId, onCodeChange, editorRef }) => {
  useEffect(() => {
    async function init() {
      if (!editorRef.current) {
        editorRef.current = CodeMirror.fromTextArea(
          document.getElementById("realtimeEditor"),
          {
            mode: { name: "javascript", json: true },
            theme: "material-ocean",
            autoCloseTags: true,
            autoCloseBrackets: true,
            lineNumbers: true,
            indentUnit: 4,
            direction: "ltr",
            extraKeys: { "Ctrl-Space": "autocomplete" },
          }
        );

        editorRef.current.on("change", (instance, changes) => {
          const { origin } = changes;
          const code = instance.getValue();
          onCodeChange(code);

          if (origin !== "setValue") {
            socketRef.current.emit(ACTIONS.CODE_CHANGE, {
              roomId,
              code,
            });
          }
        });
      }
    }
    init();
  }, []);

  useEffect(() => {
    if (socketRef.current) {
      socketRef.current.on(ACTIONS.CODE_CHANGE, ({ code }) => {
        const currentCode = editorRef.current.getValue();
        if (code !== null && code !== currentCode) {
          editorRef.current.setValue(code);
        }
      });
    }

    return () => {
      if (socketRef.current) {
        socketRef.current.off(ACTIONS.CODE_CHANGE);
      }
    };
  }, [socketRef.current]);

  return <textarea id="realtimeEditor" />;
};
